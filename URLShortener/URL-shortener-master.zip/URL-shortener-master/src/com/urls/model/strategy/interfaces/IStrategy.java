package com.urls.model.strategy.interfaces;

import com.urls.model.beans.StrategyResponseBean;

public interface IStrategy {

	public StrategyResponseBean execute(Object obj);
}
