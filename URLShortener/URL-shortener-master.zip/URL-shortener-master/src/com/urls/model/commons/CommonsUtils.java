package com.urls.model.commons;

public class CommonsUtils {

	public static String URL_PREFIX = "http://localhost:8080/URLShortener/url/"; // must be loaded from proptry file
}
